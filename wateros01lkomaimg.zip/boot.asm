[org 0x7c00]
; --- СЕКТОР 1: ЗАГРУЗЧИК (512 байт) ---
    xor ax, ax
    mov ds, ax
    mov es, ax
    mov ss, ax
    mov sp, 0x7c00
    mov [disk], dl
    mov ah, 0x02
    mov al, 10          ; Читаем 10 секторов (5 КБ)
    mov ch, 0
    mov dh, 0
    mov cl, 2           ; Начинаем со 2-го сектора
    mov dl, [disk]
    mov bx, 0x7e00      ; Грузим ядро по адресу 0x7e00
    int 0x13
    jmp 0x7e00          ; Прыгаем в ядро
disk db 0
times 510-($-$$) db 0
dw 0xaa55

; --- СЕКТОР 2: ЯДРО WATEROS (0x7e00) ---
kernel:
    ; 1. ВВОД ДАТЫ (ЧЕРНЫЙ ЭКРАН)
    mov ax, 0x0600
    mov bh, 0x07
    xor cx, cx
    mov dx, 0x184f
    int 0x10
    mov ah, 0x02
    xor bh, bh
    xor dx, dx
    int 0x10
    mov si, m_date
    call p
    call r              ; Ждем ввод даты

    ; 2. ПЕРЕХОД В СИНИЙ ИНТЕРФЕЙС
    mov bl, 0x1f
    call cls_fn

main_loop:
    call draw_t         ; ЧАСЫ В УГЛУ
    mov si, pr          ; ПРИГЛАШЕНИЕ C:\>
    call p
    call r
    
    mov al, [buffer]
    or al, al
    jz main_loop

    ; КОМАНДА ПЕРЕЗАГРУЗКИ
    mov si, buffer
    mov di, c_reb
    call comp
    jc do_reb
    
    mov si, m_err
    call p
    jmp main_loop

draw_t:
    pusha
    mov ah, 0x02
    int 0x1a            ; Читаем время из BIOS
    mov ah, 0x02
    mov bh, 0
    mov dh, 24          ; Строка 24
    mov dl, 70          ; Колонка 70
    int 0x10
    mov al, ch
    call p_bcd
    mov al, ':'
    mov ah, 0x0e
    int 0x10
    mov al, cl
    call p_bcd
    mov ah, 0x02
    mov dl, 0
    int 0x10            ; Возврат курсора в начало
    popa
    ret

p_bcd:
    push ax
    shr al, 4
    add al, '0'
    mov ah, 0x0e
    int 0x10
    pop ax
    and al, 0x0f
    add al, '0'
    mov ah, 0x0e
    int 0x10
    ret

cls_fn:
    mov ax, 0x0600
    mov bh, bl
    xor cx, cx
    mov dx, 0x184f
    int 0x10
    mov ah, 0x02
    xor bh, bh
    xor dx, dx
    int 0x10
    ret

p:  mov ah, 0x0e
.l: lodsb
    or al, al
    jz .d
    int 0x10
    jmp .l
.d: ret

r:  mov di, buffer
.l: mov ah, 0
    int 0x16
    cmp al, 13
    je .d
    mov ah, 0x0e
    int 0x10
    stosb
    jmp .l
.d: mov al, 0
    stosb
    mov ah, 0x0e
    mov al, 10
    int 0x10
    mov al, 13
    int 0x10
    ret

comp:
.l: mov al, [si]
    mov bl, [di]
    cmp al, bl
    jne .n
    or al, al
    jz .e
    inc si
    inc di
    jmp .l
.n: clc
    ret
.e: stc
    ret

do_reb: db 0xea
    dw 0, 0xffff

; --- ТЕКСТЫ ---
m_date db 'Enter Date: ', 0
pr     db 'C:\> ', 0
m_err  db 'Error!', 13, 10, 0
c_reb  db 'perekompa', 0
buffer times 64 db 0

; ДОБИВАЕМ ДО 1.44 МБ
times 1474560 - ($ - $$) db 0
